Inventory_Detail_Js("SalesOrder_Detail_Js", {}, {
    registerEvents: function() {
        this._super();
        console.log("SalesOrder Detail JS extendido y cargado");
    }
});
